from django.db import models

class Conversation(models.Model):
    scenario = models.CharField(max_length=100)  # Scenario name
    timestamp = models.DateTimeField(auto_now_add=True)  # Creation time

    def __str__(self):
        return f"{self.scenario} - {self.timestamp.strftime('%Y-%m-%d %H:%M:%S')}"

class Message(models.Model):
    conversation = models.ForeignKey(Conversation, related_name="messages", on_delete=models.CASCADE)
    role = models.CharField(max_length=10, choices=[("user", "User"), ("ai", "AI")])
    content = models.TextField()

    def __str__(self):
        return f"{self.role}: {self.content[:30]}"
